package mainApp;

/**
 * Class: Fuel <br>
 * Purpose: Represents a fuel resource object in the game <br>
 * For example:
 * 
 * <pre>
 * Fuel fuel = new Fuel(150, 300);
 * </pre>
 * 
 * <br>
 * Inheritance: Extends the ResourceObject class
 * 
 * @author Ahaan Kothari, Adi Sangole, Bryce Lloyd
 */
public class Fuel extends ResourceObject {

	/**
	 * ensures: initializes the fuel object's coordinates and sets the image for
	 * fuel
	 * 
	 * @param xPosition the x-coordinate of the fuel's initial position
	 * @param yPosition the y-coordinate of the fuel's initial position
	 */
	public Fuel(int xPosition, int yPosition) {
		super(xPosition, yPosition, "src/Graphics/fire-removebg-preview.png");
	}

	/**
	 * ensures: activates the fuel resource, making it able to be collected
	 */
	public void activate() {
		this.active = true;
	}

	/**
	 * ensures: updates the fuel resource
	 */
	@Override
	public void update() {

	}

}
