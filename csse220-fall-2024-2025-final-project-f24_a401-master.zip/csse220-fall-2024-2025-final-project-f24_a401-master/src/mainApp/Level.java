package mainApp;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.Scanner;

import javax.imageio.ImageIO;
import javax.swing.JPanel;
import javax.swing.Timer;

/**
 * Class: Level <br>
 * Purpose: handles everything related to adding objects on the screen of a
 * level
 */
public class Level extends JPanel {
	private Timer timer;
	private static final long serialVersionUID = 1L;
	private Rosie rosie;
	private List<Platform> platformsList;
	private List<Bonfire> piecesList;
	private List<Fuel> fuelList;
	private List<Enemy> enemies;
	private List<Resource> resources;
	private BufferedImage img;
	private MainApp mainApp;
	private List<Projectile> projectiles = new ArrayList<>();

	/**
	 * ensures: initializes the level
	 * 
	 * @param mainApp the mainApp
	 */
	public Level(MainApp mainApp) {
		this.platformsList = new ArrayList<>();
		this.piecesList = new ArrayList<>();
		this.fuelList = new ArrayList<>();
		this.resources = new ArrayList<>();
		this.enemies = new ArrayList<>();
		this.mainApp = mainApp;

		timer = new Timer(50, e -> repaint());
		timer.start();
		try {
			File file = new File("src/Graphics/gamebg.png");
			img = ImageIO.read(file);
		} catch (IOException e) {
			e.printStackTrace();
		}

		generateRandomResources(10);
	}

	/**
	 * ensures: generates resources in random locations
	 * 
	 * @param numCoins the number of resources to generate
	 */
	private void generateRandomResources(int numCoins) {
		Random random = new Random();
		for (int i = 0; i < numCoins; i++) {
			int x = random.nextInt(750);
			int y = random.nextInt(550);
			Resource coin = new Resource(x, y);
			resources.add(coin);
		}

	}

	/**
	 * ensures: resets the level by clearing it
	 */
	public void reset() {
		platformsList.clear();
		piecesList.clear();
		fuelList.clear();
		enemies.clear();
		resources.clear();
		rosie = null;
	}

	/**
	 * ensures: gets the list of enemies
	 * 
	 * @return a list of enemies
	 */
	public List<Enemy> getEnemies() {
		return enemies;
	}

	/**
	 * ensures: gets the list of bonfire pieces
	 * 
	 * @return a list of bonfire pieces
	 */
	public List<Bonfire> getPiecesList() {
		return piecesList;
	}

	/**
	 * ensures: gets the list of fuel
	 * 
	 * @return a list of fuel
	 */
	public List<Fuel> getFuelList() {
		return fuelList;
	}

	/**
	 * ensures: gets the list of platforms
	 * 
	 * @return a list of platforms
	 */
	public List<Platform> getPlatformsList() {
		return platformsList;
	}

	/**
	 * ensures: stops the timer for the level
	 */
	public void timerStop() {
		if (timer != null) {
			timer.stop();
		}
	}

	/**
	 * ensures: loads a level given a txt file
	 * 
	 * @param filename the name of the file
	 * @throws InvalidLevelFormatException if the level file's formatting is
	 *                                     incorrect
	 * @throws IOException                 if the file cannot be read
	 */
	public void loadLevel(String filename) throws InvalidLevelFormatException, IOException {
		File f = new File(filename);
		try (Scanner scanner = new Scanner(f)) {
			while (scanner.hasNextLine()) {
				String nextLine = scanner.nextLine();
				String[] split = nextLine.split(" ");

				if (split.length < 3)
					throw new InvalidLevelFormatException("Invalid line format: " + nextLine);

				String objectType = split[0];
				try {
					if (objectType.equals("Hero")) {
						int xRosieCoord = Integer.parseInt(split[1]);
						int yRosieCoord = Integer.parseInt(split[2]);
						this.rosie = new Rosie(xRosieCoord, yRosieCoord);

					} else if (objectType.equals("Platform")) {
						if (split.length < 3) {
							throw new InvalidLevelFormatException("Invalid platform format: " + nextLine);
						}
						int xPlatformCoord = Integer.parseInt(split[1]);
						int yPlatformCoord = Integer.parseInt(split[2]);
						Platform platform = new Platform(xPlatformCoord, yPlatformCoord);
						this.platformsList.add(platform);
					} else if (objectType.equals("Bonfire")) {
						if (split.length < 3) {
							throw new InvalidLevelFormatException("Invalid bonfire format: " + nextLine);
						}
						int xBonfireCoord = Integer.parseInt(split[1]);
						int yBonfireCoord = Integer.parseInt(split[2]);
						Bonfire bonfire = new Bonfire(xBonfireCoord, yBonfireCoord);
						this.piecesList.add(bonfire);
					} else if (objectType.equals("Fuel")) {
						if (split.length < 3) {
							throw new InvalidLevelFormatException("Invalid fuel format: " + nextLine);
						}
						int xFuelCoord = Integer.parseInt(split[1]);
						int yFuelCoord = Integer.parseInt(split[2]);
						Fuel fuel = new Fuel(xFuelCoord, yFuelCoord);
						this.fuelList.add(fuel);
					} else {
						throw new InvalidLevelFormatException("Unknown object: " + objectType);
					}
				} catch (NumberFormatException e) {
					throw new InvalidLevelFormatException("Unknown number format: " + nextLine);
				}
			}
		} catch (FileNotFoundException e) {
			throw new IOException("File not found: " + filename, e);
		}
		if (rosie != null) {
			enemies.add(new SimpleDrone(50, 700, rosie));
			enemies.add(new FlyingDrone(650, 50, 400));
		}

	}

	/**
	 * ensures: adds a projectile
	 * 
	 * @param projectile the projectile to add
	 */
	public void addProjectile(Projectile projectile) {
		projectiles.add(projectile);
	}

	public void checkResource() {
		if (rosie != null) {
			for (int i = 0; i < resources.size(); i++) {
				Resource r = resources.get(i);
				if (rosie.checkCollision(r)) {
					r.collect(mainApp);
					resources.remove(i);
					i--;
				}
			}
		}
	}

	/**
	 * ensures: gets the rosie for the specific level
	 * 
	 * @return Rosie
	 */
	public Rosie getRosie() {

		return rosie;
	}

	public void flyRosieRight() {
		this.rosie.moveRight();
	}

	public void flyRosieLeft() {
		this.rosie.moveLeft();
	}

	public void flyRosieUp() {
		this.rosie.fly();
	}

	public void flyRosieUpRight() {
		this.rosie.fly();
		this.rosie.moveRight();
	}

	public void flyRosieUpLeft() {
		this.rosie.fly();
		this.rosie.moveLeft();
	}

	public boolean onPlatform() {
		for (Platform platform : platformsList) {
			if (rosie.getxPosition() + rosie.getWidth() / 2 >= platform.getxPosition()
					&& rosie.getxPosition() <= (platform.getxPosition() + platform.getWidth() - rosie.getWidth() / 2)) {
				if (rosie.getyPosition() >= platform.getyPosition() - rosie.getHeight()
						&& rosie.getyPosition() <= platform.getyPosition() + 5) {
					rosie.setyCoord(platform.getyPosition() - rosie.getHeight());
					return true;
				}
			}
		}
		return false;
	}

	/**
	 * ensures: updates the positions of projectiles
	 */
	public void updateProjectiles() {
		for (int i = 0; i < projectiles.size(); i++) {
			Projectile projectile = projectiles.get(i);
			projectile.move();
		}
	}

	/**
	 * ensures: adds all the objects to the level
	 * 
	 * @param g the graphics variable
	 */
	@Override
	public void paintComponent(Graphics g) {
		super.paintComponent(g);

		if (img != null) {
			g.drawImage(img, 0, 0, getWidth(), getHeight(), null);
		}
		if (rosie != null) {
			if (!onPlatform()) {
				rosie.gravityAcceleration();
			} else {
				rosie.notFalling();
			}

			if (rosie.getyPosition() > getHeight() - rosie.getHeight()) {
				rosie.setyCoord(getHeight() - rosie.getHeight());
				rosie.notFalling();
			}
			rosie.drawOn(g);
		}

		for (Platform platform : platformsList) {
			platform.drawOn(g);
		}
		if (piecesList != null) {
			for (Bonfire bonfire : piecesList) {
				bonfire.drawOn(g);
			}
		}
		if (fuelList != null) {
			for (Fuel fuel : fuelList) {
				fuel.drawOn(g);
			}
		}
		for (Resource r : resources) {
			if (r.isActive()) {
				r.drawOn(g);
			}
		}
		for (Enemy enemy : enemies) {
			enemy.update();
			enemy.drawOn(g);
		}
		for (Projectile projectile : projectiles) {
			projectile.drawOn(g);
		}

		g.setColor(Color.BLACK);
		g.setFont(new Font("Tahoma", Font.BOLD, 20));
		g.drawString("Lives: " + (rosie != null ? rosie.getLives() : 0), 10, 20);
		g.drawString("Points: " + mainApp.getPoints(), 685, 20);
		g.drawString("Time : " + mainApp.getTime() + "s", 350, 20);
	}

}