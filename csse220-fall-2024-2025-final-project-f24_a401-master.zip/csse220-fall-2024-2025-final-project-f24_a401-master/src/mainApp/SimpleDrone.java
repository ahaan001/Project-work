package mainApp;

public class SimpleDrone extends Enemy {
	private int speed = 2;
	private Rosie rosie;

	/**
	 * ensures: initializes the drone graphic and rosie
	 */
	public SimpleDrone(int yPos, int Xpos, Rosie rosie) {
		super(Xpos, yPos, 100, 85,"src/Graphics/Simple-enemy.png", 2);
		this.rosie = rosie;

	}
	/**
	 * ensures: creates the movement for the drone (Adi's face)
	 */
	@Override
	public void move() {
		if (Math.abs(rosie.getxPosition() - xPosition) > Math.abs(rosie.getyPosition() - yPosition)) {

			if (rosie.getxPosition() > xPosition)
				xPosition += speed;
			else {
				xPosition -= speed;
			}
		} else {
			if (rosie.getyPosition() > yPosition)
				yPosition += speed;
			else {
				yPosition -= speed;
			}
		}
	}

}
