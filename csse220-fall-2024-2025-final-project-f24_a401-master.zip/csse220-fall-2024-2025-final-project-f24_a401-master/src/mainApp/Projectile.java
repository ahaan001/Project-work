package mainApp;

import java.awt.Graphics;

/**
 * Class: Projectile <br>
 * Purpose: Represents a projectile in the game <br>
 * For example:
 * 
 * <pre>
 * Projectile projectile = new Projectile(100, 200, 10, "src/Graphics/Projectile.png");
 * </pre>
 * 
 * <br>
 * Inheritance: Extends the GameObject class.
 */

public class Projectile extends GameObject {
	private int speed;
	private boolean active;

	/**
	 * ensures: Initializes the projectile
	 * 
	 * @param x         the initial x-coordinate of the projectile
	 * @param y         the initial y-coordinate of the projectile
	 * @param speed     the speed of the projectile
	 * @param imagePath the file of the image location
	 */
	public Projectile(int x, int y, int speed, String imagePath) {
		super(x, y, 100, 100, imagePath);
		this.speed = speed;
		this.active = true;
	}

	/**
	 * ensures: Moves the projectile .
	 */
	public void move() {
		xPosition += speed;
		if (xPosition < 0 || xPosition > 800) {
			active = false;
		}
	}

	/**
	 * ensures: Sets the position of the projectile
	 * 
	 * @param x the x-coordinate
	 * @param y the y-coordinate
	 */
	public void setPosition(int x, int y) {
		this.xPosition = x;
		this.yPosition = y;
	}

	/**
	 * ensures: checks if projectile is active
	 * 
	 * @return true if the projectile is active, false otherwise
	 */
	public boolean isActive() {
		return active;
	}

	/**
	 * ensures: Sets activity of projectile
	 * 
	 * @param active
	 */
	public void setActive(boolean active) {
		this.active = active;
	}

	/**
	 * ensures: Draws the projectile
	 * 
	 * @param g the graphics variable
	 */
	@Override
	public void drawOn(Graphics g) {
		if (img != null) {
			g.drawImage(img, xPosition, yPosition, width, height, null);
		}
	}

	/**
	 * ensures: Updates the projectile's position
	 */
	@Override
	public void update() {
		// TODO Auto-generated method stub

	}
}
