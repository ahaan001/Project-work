package mainApp;

import java.io.*;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Class: LeaderboardManager <br>
 * Purpose: Manages the leader board
 * 
 * @author Ahaan Kothari, Adi Sangole, Bryce Lloyd
 */
public class LeaderboardManager {
	private static final String LEADERBOARD_FILE = "leaderboard.txt";
	private final List<Leaderboard> leaderboard;

	/**
	 * ensures: initializes the leader board manager
	 */
	public LeaderboardManager() {
		leaderboard = new ArrayList<>();
		loadLeaderboard();
	}

	/**
	 * ensures: adds a new entry to the leader board if criteria is met
	 * 
	 * @param playerName the name of the player
	 * @param timeTaken  the time taken
	 */
	public void addEntry(String playerName, int timeTaken) {
		leaderboard.add(new Leaderboard(playerName, timeTaken));
		Collections.sort(leaderboard);
		saveLeaderboard();
	}

	/**
	 * ensures: gets a leader board
	 * 
	 * @return sorted leader board
	 */
	public List<Leaderboard> getLeaderboard() {
		return new ArrayList<>(leaderboard);
	}

	/**
	 * ensures: loads leader board data
	 */
	private void loadLeaderboard() {
		File file = new File(LEADERBOARD_FILE);
		if (!file.exists())
			return;

		try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
			String line;
			while ((line = reader.readLine()) != null) {
				String[] parts = line.split(",");
				if (parts.length == 2) {
					leaderboard.add(new Leaderboard(parts[0], Integer.parseInt(parts[1])));
				}
			}
			Collections.sort(leaderboard);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	/**
	 * ensures: saves the leader board to the file
	 */
	private void saveLeaderboard() {
		try (BufferedWriter writer = new BufferedWriter(new FileWriter(LEADERBOARD_FILE))) {
			for (Leaderboard entry : leaderboard) {
				writer.write(entry.getPlayerName() + "," + entry.getTimeTaken());
				writer.newLine();
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}
