package mainApp;

/**
 * Class: Platform <br>
 * Purpose: Represents a platform <br>
 * For example:
 * 
 * <pre>
 * Platform platform = new Platform(200, 400);
 * </pre>
 * 
 * <br>
 * Inheritance: Extends the GameObject class.
 */
public class Platform extends GameObject {

	/**
	 * ensures: Initializes the platform.
	 * 
	 * @param xPosition the x-coordinate of the platform's position
	 * @param yPosition the y-coordinate of the platform's position
	 */
	public Platform(int xPosition, int yPosition) {
		super(xPosition, yPosition, 100, 20, "src/Graphics/Platform.jpg");
	}

	/**
	 * ensures: updates the platform
	 */
	@Override
	public void update() {
	}

}
