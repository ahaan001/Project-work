package mainApp;

import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;

/**
 * Class: GameObject <br>
 * Purpose: Represents the abstract class of a game object that with
 * coordinates, size and a graphics file <br>
 * For example:
 * 
 * <pre>
 * GameObject randomObject = new GameObject(100, 200, 50, 50, "src/graphics/graphic.png");
 * </pre>
 * 
 * @author Ahaan Kothari, Adi Sangole, Bryce Lloyd
 */
public abstract class GameObject {
	protected int xPosition;
	protected int yPosition;
	protected int width;
	protected int height;
	protected BufferedImage img;

	/**
	 * ensures: initializes the game object with the specified position, size, and
	 * graphics file
	 * 
	 * @param xPosition the x-coordinate of the game object's initial position
	 * @param yPosition the y-coordinate of the game object's initial position
	 * @param width     the width of the game object
	 * @param height    the height of the game object
	 * @param filename  for the path of the graphics file for the game object
	 */
	public GameObject(int xPosition, int yPosition, int width, int height, String filename) {
		this.xPosition = xPosition;
		this.yPosition = yPosition;
		this.width = width;
		this.height = height;
		if (filename != null) {
			createGraphics(filename);
		}
	}

	/**
	 * ensures: creates the image for the specified file
	 * 
	 * @param filename of the path
	 */
	protected void createGraphics(String filename) {
		try {
			File file = new File(filename);
			img = ImageIO.read(file);
		} catch (IOException e) {
			e.printStackTrace();
		}

	}

	/**
	 * ensures: abstract method to update any classes
	 */
	public abstract void update();

	/**
	 * ensures: draws the game object on the JPanel
	 * 
	 * @param g the graphics variable used to paint the image on the JPanel
	 */
	public void drawOn(Graphics g) {
		if (img != null) {
			g.drawImage(img, this.xPosition, this.yPosition, this.width, this.height, null);
		}

	}

	/**
	 * ensures: gets the current x-coordinate of the game object
	 * 
	 * @return the x-coordinate of the game object's position
	 */
	public int getxPosition() {
		return xPosition;
	}

	/**
	 * ensures: gets the current y-coordinate of the game object
	 * 
	 * @return the y-coordinate of the game object's position
	 */
	public int getyPosition() {
		return yPosition;
	}

	/**
	 * ensures: gets the width of the game object
	 * 
	 * @return the width of the game object
	 */
	public int getWidth() {
		return width;
	}

	/**
	 * ensures: gets the height of the game object
	 * 
	 * @return the height of the game object
	 */
	public int getHeight() {
		return height;
	}

	/**
	 * ensures: sets the position of the game object
	 * 
	 * @param x the new x-coordinate of the position
	 * @param y the new y-coordinate of the position
	 */
	public void setPosition(int x, int y) {
		this.xPosition = x;
		this.yPosition = y;
	}

	/**
	 * ensures: checks for collisions between game objects
	 * 
	 * @param any other game object
	 * @return true if the objects collide, false otherwise
	 */
	public boolean checkCollision(GameObject other) {
		if (this.xPosition < other.xPosition + other.width && this.xPosition + this.width > other.xPosition
				&& this.yPosition < other.yPosition + other.height && this.yPosition + this.height > other.yPosition)
			return true;
		return false;
	}

}
