package mainApp;

/**
 * Class: Resource <br>
 * Purpose: Represents a special resource <br>
 * For example:
 * 
 * <pre>
 * Resource resource = new Resource(300, 400);
 * </pre>
 * 
 * <br>
 * Inheritance: Extends the ResourceObject class.
 */
public class Resource extends ResourceObject {

	/**
	 * ensures: Initializes the resource
	 * 
	 * @param xPosition the x-coordinate of the resource's position
	 * @param yPosition the y-coordinate of the resources position
	 */
	public Resource(int xPosition, int yPosition) {
		super(xPosition, yPosition, "src/Graphics/resource-removebg-preview.png");
	}

	@Override
	public void update() {
	}

	/**
	 * ensures: Collects the resource, increases points
	 * 
	 * @param mainApp the mainApp
	 */
	public void collect(MainApp mainApp) {
		setActive(false);
		mainApp.increasePoints();
		;
	}

}
