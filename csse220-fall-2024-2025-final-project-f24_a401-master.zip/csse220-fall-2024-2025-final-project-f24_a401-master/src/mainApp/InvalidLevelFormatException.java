package mainApp;

/**
 * Class: InvalidLevelFormatException <br>
 * Purpose: Represents an error that is thrown when there is an invalid level
 * formatting <br>
 * For example:
 * 
 * <pre>
 * throw new InvalidLevelFormatException("Invalid format");
 * 
 * </pre>
 * 
 * <br>
 * Inheritance: Extends the Exception class
 * 
 * @author Ahaan Kothari, Adi Sangole, Bryce Lloyd
 */
public class InvalidLevelFormatException extends Exception {
	/**
	 * Serial version UID
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * ensures: gives a level format exception with an error message
	 * 
	 * @param error the error message
	 */
	public InvalidLevelFormatException(String error) {
		super(error);
	}
}
