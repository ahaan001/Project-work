package mainApp;

/**
 * Class: Leaderboard <br>
 * Purpose: Represents the leader board and the data inputed inside it <br>
 * For example:
 * 
 * <pre>
 * Leaderboard entry = new Leaderboard("Player1", 120);
 * </pre>
 * 
 * <br>
 * Implements: Comparable
 * 
 * @author Ahaan Kothari, Adi Sangole, Bryce Lloyd
 */
public class Leaderboard implements Comparable<Leaderboard> {
	private final String playerName;
	private final int timeTaken;

	/**
	 * ensures: initializes a leaderboard
	 * 
	 * @param playerName the name of the player
	 * @param timeTaken  the time taken
	 */
	public Leaderboard(String playerName, int timeTaken) {
		this.playerName = playerName;
		this.timeTaken = timeTaken;
	}

	/**
	 * ensures: gets the player's name
	 * 
	 * @return the player's name
	 */
	public String getPlayerName() {
		return playerName;
	}

	/**
	 * ensures: gets the time taken
	 * 
	 * @return the time taken
	 */
	public int getTimeTaken() {
		return timeTaken;
	}

	/**
	 * ensures: compares two entries in the leader board
	 * 
	 * @param other the other leaderboard entry
	 * @return a negative or positive number, or zero
	 */
	@Override
	public int compareTo(Leaderboard other) {
		return Integer.compare(this.timeTaken, other.timeTaken);
	}

	/**
	 * ensures: creates a string with the entry
	 * 
	 * @return a string with player name and time taken
	 */
	@Override
	public String toString() {
		return playerName + ": " + timeTaken + "s";
	}
}
