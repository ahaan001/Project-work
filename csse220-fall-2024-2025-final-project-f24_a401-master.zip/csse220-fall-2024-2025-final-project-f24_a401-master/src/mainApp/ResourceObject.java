package mainApp;

import java.awt.Graphics;
/**
 * Class: ResourceObject
 * <br>Purpose: Represents an abstract class for resource objects
 * <br>For example:
 * <pre>
 * ResourceObject resource = new Resource(x, y, "path/to/image.png");
 * </pre>
 * <br>Inheritance: Extends the GameObject class.
 */
public abstract class ResourceObject extends GameObject {
	protected boolean active;
	/**
	 * ensures: initializes resourceobject positions and if it is on (active) or not
	 */

	public ResourceObject(int xPosition, int yPosition, String filename) {
		super(xPosition, yPosition, 50, 50, filename);
		this.active = true;
	}
	/**
	 * ensures: sets resourceobject position
	 */
	public void setPosition(int x, int y) {
		this.xPosition = x;
		this.yPosition = y;
	}
	/**
	 * ensures: checks if it is on
	 */
	public boolean isActive() {
		return active;
	}
	/**
	 * ensures: turns it on
	 */
	public void setActive(boolean active) {
		this.active = active;
	}
	/**
	 * ensures: draws resourceobjects
	 */
	@Override
	public void drawOn(Graphics g) {
		if (img != null) {
			g.drawImage(img, this.xPosition, this.yPosition, this.width, this.height, null);
		}
	}


	}
