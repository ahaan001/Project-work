package mainApp;

import java.awt.Graphics;

/**
 * Class: Enemy <br>
 * Purpose: Represents an abstract enemy class in the game with movement
 * capabilities <br>
 * For example:
 * 
 * <pre>
 * Enemy enemy = new SimpleDrone(100, 200, 50, 50, "src/Graphics/enemy.png", 5);
 * </pre>
 * 
 * <br>
 * Inheritance: Extends the GameObject class
 * 
 * @author Ahaan Kothari, Adi Sangole, Bryce Lloyd
 */
public abstract class Enemy extends GameObject {

	protected int moveSpeed;
	private boolean active = true;

	/**
	 * ensures: initializes the enemy's position, size, image, and movement speed
	 * 
	 * @param xPosition the x-coordinate of the enemy's initial position
	 * @param yPosition the y-coordinate of the enemy's initial position
	 * @param width     the width of the enemy
	 * @param height    the height of the enemy
	 * @param filename  the path to the image file for enemy
	 * @param moveSpeed the speed of the enemy
	 */
	public Enemy(int xPosition, int yPosition, int width, int height, String filename, int moveSpeed) {
		super(xPosition, yPosition, width, height, filename);
		this.moveSpeed = moveSpeed;
	}

	/**
	 * ensures: draws the enemy using the Graphics class
	 * 
	 * @param g the graphics variable used to paint the image on the JPanel
	 */
	@Override
	public void drawOn(Graphics g) {
		if (img != null && active) {
			g.drawImage(img, this.xPosition, this.yPosition, this.width, this.height, null);
		}
	}

	/**
	 * ensures: returns whether the enemy is currently active
	 * 
	 * @return true if the enemy is active, false otherwise
	 */
	public boolean isActive() {
		return active;
	}

	/**
	 * ensures: sets the active variable for the enemy
	 * 
	 * @return the new active variable for the enemy
	 */
	public void setActive(boolean active) {
		this.active = active;
	}

	/**
	 * ensures: movement for the enemy
	 */
	public abstract void move();

	/**
	 * ensures: updates enemy behavior
	 */
	@Override
	public void update() {
		move();
	}

	/**
	 * ensures: gets the current x-coordinate of the enemy
	 * 
	 * @return the x-coordinate of the enemy's position
	 */
	public int getXPos() {
		return xPosition;
	}

	/**
	 * ensures: gets the current y-coordinate of the enemy
	 * 
	 * @return the y-coordinate of the enemy's position
	 */
	public int getYPos() {
		return yPosition;
	}
}
