package mainApp;

/**
 * Class: FlyingDrone
 * <br>Purpose: Represents a dinosaur that moves up and down
 * <br>For example:
 * <pre>
 *    FlyingDrone drone = new FlyingDrone(200, 100, 300);
 * </pre>
 * <br>Inheritance: Extends the Enemy class
 * @author Ahaan Kothari, Adi Sangole, Bryce Lloyd
 */
public class FlyingDrone extends Enemy {
	private int minY;
	private int maxY;
	private int speed = 5;
	private boolean down = true;

	 /**
     * ensures: initializes the dinosaur's position and limits its range
     * @param xPos the initial X position of the dinosaur
     * @param minY the minimum Y position of the dinosaur 
     * @param maxY the maximum Y position of the dinosaur 
     */
	public FlyingDrone(int xPos, int minY, int maxY) {
		super(xPos,minY,100, 85, "src/Graphics/crocodile-removebg-preview.png", 5);
		this.minY = minY;
		this.maxY = maxY;
		
	}
	/**
     * ensures: updates the dinosaur's position
     */
	@Override
	public void move() {
		if (down) {
			yPosition += speed;
			if (yPosition >= maxY)down = false;
		} else {
			yPosition -= speed;
			if (yPosition <= minY)down = true;
		}

	}

}
