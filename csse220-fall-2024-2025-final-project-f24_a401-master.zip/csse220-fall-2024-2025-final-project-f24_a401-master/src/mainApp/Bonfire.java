package mainApp;

/**
 * Class: Bonfire <br>
 * Purpose: Represents a bonfire resource in the game <br>
 * For example:
 * 
 * <pre>
 * Bonfire bonfire = new Bonfire(100, 200);
 * </pre>
 * 
 * This creates a bonfire resource at position (100, 200) with the image. <br>
 * Inheritance: Extends the ResourceObject class
 * 
 * @author Ahaan Kothari, Adi Sangole, Bryce Lloyd
 */
public class Bonfire extends ResourceObject {

	/**
	 * ensures: initializes the bonfire resource
	 * 
	 * @param xPosition the x-coordinate of the bonfire's initial position
	 * @param yPosition the y-coordinate of the bonfire's initial position
	 */
	public Bonfire(int xPosition, int yPosition) {
		super(xPosition, yPosition, "src/Graphics/firewood_final-removebg-preview.png");

	}

	/**
	 * ensures: updates the bonfire
	 */
	@Override
	public void update() {

	}

	/**
	 * ensures: checks if the bonfire is in its position
	 * 
	 * @return true if the bonfire is in the correct position, false otherwise
	 */
	public boolean inPosition() {
		return false;
	}

}
