package mainApp;

import java.util.List;

/**
 * Class: CollisionHandler <br>
 * Purpose: Deals with collision detection between all game objects <br>
 * For example:
 * 
 * <pre>
 * CollisionHandler.isCollidingWithEnemy(rosie, enemies)
 * </pre>
 * 
 * @author Ahaan Kothari, Adi Sangole, Bryce Lloyd
 */
public class CollisionHandler {
	private static int collectedBonfireCount = 0;
	private static int collectedFuelCount = 0;
	private static final int collectedX = 735;
	private static final int collectedY = 535;
	private static final int stackOffset = -10;
	private static boolean allBonfireCollected = false;

	/**
	 * ensures: checks if rosie collides with an enemy
	 * 
	 * @param rosie   the hero
	 * @param enemies list of enemies
	 * @return true if Rosie collides with enemies, false otherwise
	 */
	public static boolean isCollidingWithEnemy(Rosie rosie, List<Enemy> enemies) {
		int rosieX = rosie.getxPosition();
		int rosieY = rosie.getyPosition();
		int rosieSize = 50;

		for (Enemy enemy : enemies) {
			if (!enemy.isActive()) {
				continue;
			}
			int enemyX = enemy.getXPos();
			int enemyY = enemy.getYPos();
			int enemyWidth, enemyHeight;

			if (enemy instanceof FlyingDrone) {
				enemyWidth = 100;
				enemyHeight = 85;
			} else if (enemy instanceof SimpleDrone) {
				enemyWidth = 100;
				enemyHeight = 85;
			} else {
				continue;
			}

			boolean collisionX = rosieX < enemyX + enemyWidth && rosieX + rosieSize > enemyX;
			boolean collisionY = rosieY < enemyY + enemyHeight && rosieY + rosieSize > enemyY;

			if (collisionX && collisionY) {
				return true;
			}
		}
		return false;
	}

	/**
	 * ensures: checks if Rosie is colliding with any resource objects
	 * 
	 * @param rosie      the hero
	 * @param piecesList the list of bonfire pieces
	 * @param fuellist   the list of fuel
	 * @param mainApp    the mainApp
	 * @return true if rosie collides, false otherwise
	 */
	public static boolean isCollidingWithObjects(Rosie rosie, List<Bonfire> piecesList, List<Fuel> fuellist,
			MainApp mainApp) {
		int rosieX = rosie.getxPosition();
		int rosieY = rosie.getyPosition();
		int rosieSize = 50;

		for (int i = 0; i < piecesList.size(); i++) {
			Bonfire bonfire = piecesList.get(i);

			if (!bonfire.isActive()) {
				continue;
			}

			int xBonfire = bonfire.getxPosition();
			int yBonfire = bonfire.getyPosition();
			int widthBonfire = bonfire.getWidth();
			int heightBonfire = bonfire.getHeight();

			boolean collisionX = (rosieX + rosie.getWidth() > xBonfire && rosieX < xBonfire + widthBonfire);
			boolean collisionY = rosieY < yBonfire + heightBonfire && rosieY > yBonfire;

			if (collisionX && collisionY) {
				bonfire.setPosition(collectedX, collectedY + collectedBonfireCount * stackOffset);
				bonfire.setActive(false);
				collectedBonfireCount++;

				if (collectedBonfireCount == piecesList.size()) {
					allBonfireCollected = true;
					for (Fuel fuel : fuellist) {
						fuel.activate();
					}
				}
				mainApp.increasePoints();
				return true;
			}

		}

		for (Fuel fuel : fuellist) {

			if (!fuel.isActive()) {
				continue;
			}

			int xFuel = fuel.getxPosition();
			int yFuel = fuel.getyPosition();
			int widthFuel = fuel.getWidth();
			int heightFuel = fuel.getHeight();

			boolean collisionX = rosieX < xFuel + widthFuel && rosieX + rosieSize > xFuel;
			boolean collisionY = rosieY < yFuel + heightFuel && rosieY + rosieSize > yFuel;

			if (collisionX && collisionY && collectedBonfireCount == 5) {
				fuel.setPosition(collectedX, collectedY + (collectedBonfireCount + collectedFuelCount) * stackOffset);
				fuel.setActive(false);
				collectedFuelCount++;
				mainApp.increasePoints();
				return true;
			}
		}

		if (collectedBonfireCount == piecesList.size() && collectedFuelCount == fuellist.size()) {
			mainApp.checkWin();
		}

		return false;
	}

	/**
	 * ensures: checks if Rosie is colliding with any platforms
	 * 
	 * @param rosie        the hero
	 * @param platformList the list of platforms
	 * @return true if rosie collides, false otherwise
	 */
	public static boolean isCollidingWithPlatform(Rosie rosie, List<Platform> platformList) {
		int rosieX = rosie.getxPosition();
		int rosieY = rosie.getyPosition();
		int rosieSize = 50;

		for (int i = 0; i < platformList.size(); i++) {
			Platform platform = platformList.get(i);

			int xPlatform = platform.getxPosition();
			int yPlatform = platform.getyPosition();
			int widthPlatform = platform.getWidth();
			int heightPlatform = platform.getHeight();

			boolean collisionX = (rosieX + rosie.getWidth() > xPlatform && rosieX < xPlatform + widthPlatform);
			boolean collisionY = rosieY < yPlatform + heightPlatform && rosieY > yPlatform;

			if (collisionX && collisionY) {
				return true;
			}
		}

		return false;
	}

	/**
	 * ensures: checks if two game objects collide
	 * 
	 * @param object1 first object
	 * @param object2 second object
	 * @return true if objects collide, false otherwise
	 */
	private static boolean isColliding(GameObject object1, GameObject object2) {
		return object1.getxPosition() < object2.getxPosition() + object2.getWidth()
				&& object1.getxPosition() + object1.getWidth() > object2.getxPosition()
				&& object1.getyPosition() < object2.getyPosition() + object2.getHeight()
				&& object1.getyPosition() + object1.getHeight() > object2.getyPosition();
	}

	/**
	 * ensures: deals with collisions between enemies and projectiles
	 * 
	 * @param projectiles the list of projectiles
	 * @param enemies     the list of enemies
	 * @return true if a projectiles collide, false otherwise
	 */
	public static boolean handleProjectileEnemyCollisions(List<Projectile> projectiles, List<Enemy> enemies) {
		for (Projectile projectile : projectiles) {
			if (!projectile.isActive())
				continue;

			for (Enemy enemy : enemies) {
				if (enemy.isActive() && isColliding(projectile, enemy)) {
					projectile.setPosition(-100, -100);
					projectile.setActive(false);
					enemy.setActive(false);
					return true;
				}
			}
		}
		return false;
	}

	/**
	 * ensures: resets counters for resource objects
	 */
	public static void resetCounters() {
		collectedBonfireCount = 0;
		collectedFuelCount = 0;
		allBonfireCollected = false;
	}

}
