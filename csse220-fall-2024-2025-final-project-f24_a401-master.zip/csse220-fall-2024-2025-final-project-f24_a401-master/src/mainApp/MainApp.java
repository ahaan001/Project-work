package mainApp;

import java.awt.BorderLayout;
import java.awt.CardLayout;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.io.IOException;
import java.util.List;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.SwingConstants;
import javax.swing.Timer;

/**
 * Class: MainApp <br>
 * Purpose: Top level class for CSSE220 Project containing main method <br>
 * Restrictions: None <br>
 * For example:
 * 
 * <pre>
 * public static void main(String[] args) {
 * 	new MainApp();
 * }
 * </pre>
 */
public class MainApp {
	private JFrame frame;
	private JPanel mainPanel;
	private CardLayout cardLayout;
	private Level currentLevel;
	private int levelIndex = 0;
	private boolean goingUp = false;
	private boolean goingLeft = false;
	private boolean goingRight = false;
	private int points = 0;
	private Timer playerTimer;
	private int time;
	private LeaderboardManager leaderboardManager;

	/**
	 * ensures: Initializes the mainApp by setting JFrame
	 */
	public MainApp() {

		frame = new JFrame("Ros Bonfir!");
		frame.setSize(800, 600);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		leaderboardManager = new LeaderboardManager();
		cardLayout = new CardLayout();
		mainPanel = new JPanel(cardLayout);
		mainPanel.add(createStartScreen(), "StartScreen");
		mainPanel.add(createHelpScreen(), "HelpScreen");
		this.currentLevel = new Level(this);
		mainPanel.add(currentLevel, "GameScreen");
		frame.add(mainPanel);
		mainPanel.setFocusable(true);
		frame.setVisible(true);

		time = 0;
		startPlayerTimer();
		try {
			currentLevel.loadLevel("src/level/level" + levelIndex);
		} catch (InvalidLevelFormatException e) {
			System.err.println("No file exists");
			e.printStackTrace();
		} catch (IOException e) {
			System.err.println("Level file is incorrect");
			e.printStackTrace();
		}

		Timer timer = new Timer(50, new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				moveRosie();
				checkCollisions();
				currentLevel.updateProjectiles();
				currentLevel.repaint();
			}
		});
		timer.start();

		mainPanel.addKeyListener(new KeyAdapter() {
			@Override
			public void keyPressed(KeyEvent e) {
				int key = e.getKeyCode();
				if (key == KeyEvent.VK_UP) {
					goingUp = true;
				}
				if (key == KeyEvent.VK_RIGHT) {
					goingRight = true;
				}
				if (key == KeyEvent.VK_LEFT) {
					goingLeft = true;
				}
				if (key == KeyEvent.VK_U) {
					loadIndexLevel(1);
				}
				if (key == KeyEvent.VK_D) {
					loadIndexLevel(-1);
				}
				if (key == KeyEvent.VK_SPACE) {
					currentLevel.getRosie().shoot();
				}
				moveRosie();
				checkCollisions();
				currentLevel.repaint();
			}

			public void keyReleased(KeyEvent e) {
				int key = e.getKeyCode();
				if (key == KeyEvent.VK_UP) {
					goingUp = false;
				}
				if (key == KeyEvent.VK_RIGHT) {
					goingRight = false;
				}
				if (key == KeyEvent.VK_LEFT) {
					goingLeft = false;
				}
			}
		});

	}

	/**
	 * ensures: Starts the timer tracker player
	 */
	private void startPlayerTimer() {
		playerTimer = new Timer(1000, new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				time++;
				currentLevel.repaint();
			}

		});
		playerTimer.start();

	}

	/**
	 * ensures: moves rosie according to user input
	 */
	private void moveRosie() {
		if (currentLevel.getRosie() != null) {
			Rosie rosie = currentLevel.getRosie();
			List<Platform> platformList = currentLevel.getPlatformsList();

			if (goingUp && goingRight && !CollisionHandler.isCollidingWithPlatform(rosie, platformList)) {
				currentLevel.flyRosieUpRight();
			} else if (goingUp && goingLeft && !CollisionHandler.isCollidingWithPlatform(rosie, platformList)) {
				currentLevel.flyRosieUpLeft();
			} else if (goingUp && !CollisionHandler.isCollidingWithPlatform(rosie, platformList)) {
				currentLevel.flyRosieUp();
			} else if (goingRight && !CollisionHandler.isCollidingWithPlatform(rosie, platformList)) {
				currentLevel.flyRosieRight();
			} else if (goingLeft && !CollisionHandler.isCollidingWithPlatform(rosie, platformList)) {
				currentLevel.flyRosieLeft();
			} else
				currentLevel.getRosie().gravityAcceleration();
		}
	}

	/**
	 * ensures: Starts the game by initializing timers
	 */
	public void startGame() {
		time = 0;
		playerTimer.start();
		cardLayout.show(mainPanel, "GameScreen");
		mainPanel.requestFocusInWindow();
	}

	/**
	 * ensures: Ends the game by stopping timers and sending message
	 */
	public void endGame() {
		if (playerTimer != null) {
			playerTimer.stop();
		}
		if (currentLevel.getRosie().getLives() != 0) {
			String playerName = JOptionPane.showInputDialog(frame, "Enter your name for the leaderboard:");
			if (playerName != null && !playerName.isEmpty()) {
				leaderboardManager.addEntry(playerName, time);
			}
		}
	}

	/**
	 * ensures: creates a start screen
	 * 
	 * @return a JPanel with the screen
	 */
	private JPanel createStartScreen() {
		JPanel startPanel = new JPanel(new GridBagLayout());
		GridBagConstraints gbc = new GridBagConstraints();
		gbc.insets = new Insets(10, 10, 10, 10);

		JButton startButton = new JButton("Start");
		startButton.addActionListener(e -> startGame());

		JButton helpButton = new JButton("Help");
		helpButton.addActionListener(e -> cardLayout.show(mainPanel, "HelpScreen"));

		JButton leaderboardButton = new JButton("Leaderboard");
		leaderboardButton.addActionListener(e -> showLeaderboard());

		gbc.gridx = 0;
		gbc.gridy = 0;
		startPanel.add(startButton, gbc);

		gbc.gridy = 1;
		startPanel.add(helpButton, gbc);

		gbc.gridy = 2;
		startPanel.add(leaderboardButton, gbc);

		return startPanel;
	}

	/**
	 * ensures: creates the instruction panel
	 * 
	 * @return a JPanel with instructions
	 */
	private JPanel createHelpScreen() {
		JPanel helpPanel = new JPanel(new BorderLayout());
		JLabel helpLabel = new JLabel(
				"<html><div style='text-align: center;'>Instructions:<br>Use up, left, and right arrow keys to move.<br>You MUST collect all bonfire pieces before having access to collecting the fuel.<br>Collect all items to win and write your name for the leaderboard!</div></html>",
				SwingConstants.CENTER);
		JButton backButton = new JButton("Back to Start");

		helpPanel.add(helpLabel, BorderLayout.CENTER);
		helpPanel.add(backButton, BorderLayout.SOUTH);

		backButton.addActionListener(e -> cardLayout.show(mainPanel, "StartScreen"));
		return helpPanel;
	}

	/**
	 * ensures: Displays the leaderboard
	 */
	private void showLeaderboard() {
		JPanel leaderboardPanel = new JPanel(new BorderLayout());
		StringBuilder leaderboardText = new StringBuilder("<html><div style='text-align: center;'>Leaderboard:<br>");

		for (Leaderboard entry : leaderboardManager.getLeaderboard()) {
			leaderboardText.append(entry.toString()).append("<br>");
		}
		leaderboardText.append("</div></html>");

		JLabel leaderboardLabel = new JLabel(leaderboardText.toString(), SwingConstants.CENTER);
		JButton backButton = new JButton("Back to Start");
		backButton.addActionListener(e -> cardLayout.show(mainPanel, "StartScreen"));

		leaderboardPanel.add(leaderboardLabel, BorderLayout.CENTER);
		leaderboardPanel.add(backButton, BorderLayout.SOUTH);

		mainPanel.add(leaderboardPanel, "LeaderboardScreen");
		cardLayout.show(mainPanel, "LeaderboardScreen");
	}

	/**
	 * ensures: loads the level of any index
	 * 
	 * @param count positive for higher level, negative for lower level
	 */
	public void loadIndexLevel(int count) {
		this.levelIndex += count;
		CollisionHandler.resetCounters();
		currentLevel.timerStop();
		mainPanel.remove(currentLevel);
		currentLevel = new Level(this);
		mainPanel.add(currentLevel, "GameScreen");
		try {
			currentLevel.loadLevel("src/level/level" + levelIndex);
		} catch (InvalidLevelFormatException e) {
			System.err.println("Error loading level: " + e.getMessage());
			System.err.println("Please make sure that the level file follows the correct format");
		} catch (IOException e) {
			System.err.println("File error: " + e.getMessage());
			System.err.println("Please check to make sure that the file exists");
		}
		currentLevel.revalidate();
		currentLevel.repaint();
		for (Fuel fuel : currentLevel.getFuelList()) {
			fuel.activate();
		}
		cardLayout.show(mainPanel, "GameScreen");
	}

	/**
	 * ensures: Checks for collisions between rosie and a game object
	 */
	private void checkCollisions() {
		if (currentLevel.getRosie() != null) {
			if (CollisionHandler.isCollidingWithEnemy(currentLevel.getRosie(), currentLevel.getEnemies())) {
				currentLevel.getRosie().loseLife();
				points = 0;
				System.out.println("Collision detected! Rosie's lives: " + currentLevel.getRosie().getLives());

				if (currentLevel.getRosie().getLives() <= 0) {
					JOptionPane.showMessageDialog(frame, "Game Over!");
					int restart = JOptionPane.showConfirmDialog(frame, "Restart game?", null,
							JOptionPane.YES_NO_OPTION);
					if (restart == JOptionPane.YES_OPTION) {
						restartGame();
					} else {
						System.exit(0);
					}
				} else {
					updateLives(currentLevel.getRosie().getLives());
				}
			}
			if (CollisionHandler.isCollidingWithObjects(currentLevel.getRosie(), currentLevel.getPiecesList(),
					currentLevel.getFuelList(), this)) {
				System.out.println();
				currentLevel.repaint();
				checkWin();
			}

			CollisionHandler.handleProjectileEnemyCollisions(currentLevel.getRosie().getProjectiles(),
					currentLevel.getEnemies());
			currentLevel.checkResource();
		}
	}

	/**
	 * ensures: Increases the player's points
	 */
	public void increasePoints() {
		points++;

	}

	/**
	 * ensures: resets everything and restarts the game
	 */
	public void restartGame() {
		endGame();
		points = 0;
		levelIndex = 0;
		CollisionHandler.resetCounters();

		mainPanel.remove(currentLevel);
		currentLevel = new Level(this);
		try {
			currentLevel.loadLevel("src/level/level" + levelIndex);
			if (currentLevel.getRosie() == null) {
				throw new IllegalStateException("Rosie is not initialized in the level.");
			}
		} catch (Exception e) {
			System.err.println("Error restarting game: " + e.getMessage());
			e.printStackTrace();
		}

		mainPanel.add(currentLevel, "GameScreen");
		cardLayout.show(mainPanel, "StartScreen");
		mainPanel.revalidate();
		mainPanel.repaint();
	}

	/**
	 * ensures: checks if the player has won
	 */
	void checkWin() {
		boolean allBonfireCollected = true;
		for (Bonfire pieces : currentLevel.getPiecesList()) {
			if (pieces.isActive()) {
				allBonfireCollected = false;
				break;
			}
		}
		boolean allFuelCollected = true;
		for (Fuel fuel : currentLevel.getFuelList()) {
			if (fuel.isActive()) {
				allFuelCollected = false;
				break;
			}
		}
		if (allBonfireCollected && allFuelCollected) {
			if (levelIndex == 2) {
				endGame();
				JOptionPane.showMessageDialog(frame, "You Win!");
				int restart = JOptionPane.showConfirmDialog(frame, "Restart game?", null, JOptionPane.YES_NO_OPTION);
				if (restart == JOptionPane.YES_OPTION) {
					restartGame();
				} else {
					System.exit(0);
				}
			} else {
				loadIndexLevel(1);
			}
		}
	}

	/**
	 * ensures: gets the current points
	 * 
	 * @return the current points
	 */
	public int getPoints() {
		return points;
	}

	/**
	 * ensures: gets the time.
	 * 
	 * @return the player's time
	 */
	public int getTime() {
		return time;
	}

	/**
	 * ensures: Updates the game lives
	 * 
	 * @param lives the updated number of lives
	 */
	private void updateLives(int lives) {
		currentLevel.timerStop();
		frame.remove(currentLevel);
		currentLevel = new Level(this);

		try {
			currentLevel.loadLevel("src/level/level" + levelIndex);
		} catch (InvalidLevelFormatException e) {
			System.err.println("Error loading level: " + e.getMessage());
			System.err.println("Please make sure that the level file follows the correct format");
		} catch (IOException e) {
			System.err.println("File error: " + e.getMessage());
			System.err.println("Please check to make sure that the file exists");
		}

		if (currentLevel.getRosie() != null) {
			currentLevel.getRosie().setLives(lives);
		}
		frame.add(currentLevel);
		currentLevel.revalidate();
		currentLevel.repaint();

	}

	/**
	 * The main method initialization
	 * 
	 * @param args
	 */
	public static void main(String[] args) {
		new MainApp();

	}
}
