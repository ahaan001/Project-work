package mainApp;

import java.awt.Graphics;

import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.imageio.ImageIO;
/**
 * Class: Rosie
 * <br>Purpose: Represents the hero and its movements
 * <br>For example:
 * <pre>
 * Rosie rosie =  new Rosie(100,200,50,50,null);
 * </pre>
 * <br>Inheritance: Extends the GameObject class.
 */
public class Rosie extends GameObject {
	/**
	 * ensures: generates rosie's movement, gravity, lives, points, image, and projectiles
	 */
	private double velocity;
	private static final int TERMINAL_VELOCITY = 5;
	private static final double GRAVITY = 0.1;
	private final int MOVE_ROSIE = 10;
	private int lives;
	private int points;
	private int height = 50;
	private int width = 50;
	private BufferedImage rosieLeft;
	private BufferedImage rosieRight;
	private BufferedImage img;
	private List<Projectile> projectiles;
	/**
	 * ensures: initializes Rosie's functions
	 */
	public Rosie(int xPosition, int yPosition) {
		super(xPosition, yPosition, 50, 50, null);
		projectiles = new ArrayList<>();
		this.lives = 3;
		/**
		 * ensures: loads both of Rosie's image files (right and left)
		 */
		try {
			File file = new File("src/Graphics/Rosie.png");
			File file2 = new File("src/Graphics/RosieFlipped.png");
			rosieLeft = ImageIO.read(file);
			rosieRight = ImageIO.read(file2);
		} catch (IOException e) {
			e.printStackTrace();
		}

		img = rosieRight;

	}
	/**
	 * ensures: Rosie's shoot functionality
	 */
	public void shoot() {
		int projectileSpeed = img == rosieRight ? 10 : -10;
        projectiles.add(new Projectile(xPosition + width / 2, yPosition + height / 2, projectileSpeed, "src/Graphics/Bomb.png"));
    }
	/**
	 * ensures: creates Rosie's projectiles
	 */
	public List<Projectile> getProjectiles() {
		return projectiles;
	}
	/**
	 * ensures: Pastes Rosie's projectiles on the screen and removes if they aren't active
	 */
	public void updateProjectiles() {
		for (Projectile projectile : projectiles) {
            projectile.move();
            if (!projectile.isActive()) {
                projectiles.remove(projectile);
            }
        }
	}
	/**
	 * ensures: Rosie's gravity implementation
	 */
	public void gravityAcceleration() {
		if (TERMINAL_VELOCITY > this.velocity) {
			velocity += GRAVITY;
		}
		yPosition += velocity;
	}
	/**
	 * ensures: makes Rosie not fall
	 */
	public void notFalling() {
		velocity = 0;
	}
	/**
	 * ensures: moves Rosie
	 */
	public void moveRight() {
		xPosition += MOVE_ROSIE;
		wrapAround();
		img = rosieRight;
	}

	public void moveLeft() {
		xPosition -= MOVE_ROSIE;
		wrapAround();
		img = rosieLeft;

	}
	/**
	 * ensures: wraps Rosie around the screen
	 */
	private void wrapAround() {
		if (xPosition < 0) {
			xPosition = 800 - this.height;
		}
		if (xPosition > 800 - this.height) {
			xPosition = 0;
		}
	}
	/**
	 * ensures: moves Rosie up
	 */
	public void fly() {
		this.notFalling();
		if (yPosition > 20) {
			yPosition -= MOVE_ROSIE;
		}
	}
	/**
	 * ensures: draws Rosie on the screen
	 */
	@Override
	public void drawOn(Graphics g) {
		if (img != null) {
			g.drawImage(img, this.xPosition, this.yPosition, this.height, this.width, null);
		}
		for (Projectile projectile : projectiles) {
            projectile.drawOn(g);
        }
	}
	/**
	 * ensures: Rosie loses life if she has them
	 */
	public void loseLife() {
		if (lives > 0) {
			lives--;
		}
	}
	/**
	 * ensures: Rosie gains points
	 */
	public void gainPoints() {
			points++;
	}
	/**
	 * ensures: Rosie has 3 lives
	 */
	public int getLives() {
		return lives;
	}
	/**
	 * ensures: sets Rosie's lives
	 */
	public void setLives(int lives) {
		this.lives = lives;
	}
	/**
	 * ensures: updates Rosie's projectiles
	 */
	@Override
	public void update() {
		updateProjectiles();
	}

	/**
	 * @param yCoord the yCoord to set
	 */
	public void setyCoord(int yCoord) {
		this.yPosition = yCoord;
	}


}